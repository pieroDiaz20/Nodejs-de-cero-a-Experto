
const saludar = ( nombre ) => {
    return `Saludos ${ nombre }`; // 'Saludos ' + nombre;
}

console.log( saludar( 'Fernando' ) );


